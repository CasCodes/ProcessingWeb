Java Processing 4

# Java Processing 4
### 10.09.21
### 4.1 a
```JAVA
PVector v1 = new PVector(8977,234);
PVector v2 = new PVector(8557,165);
void setup(){
  println(v1.sub(v2));
  println(v1.add(v2));
}
```
***
### 4.1 b
```JAVA
PVector a = new PVector(0, 250);
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  ellipse(a.x, a.y, 100, 100);
  a.x+=3;
  if (a.x > 500+100){
    a.x = 0;
  }
}
```
***
### 4.1 c
```JAVA
	PVector c = new PVector(69,420-69);
float g = 0;
float b = 0;

void draw(){
  background(0, g, b);
}
void keyPressed(){
  if (key == '1'){
    g = c.x;
    b = c.y;
  }
  else if (key == '2'){
    g = 0;
    b = 0;
  }
}
```
***
### 4.1 d
```JAVA
PVector v = new PVector(250, 250);
float sx = 3;
float sy = 2;
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  ellipse(v.x , v.y, 50, 50);
  v.x+=sx;
  v.y+=sy;
  if (v.x > 475 || v.x < 25){
    sx = -sx;
  }
  if (v.y > 475 || v.y < 25){
    sy = -sy;
  }
}
```
***
### 4.1 e
```JAVA
PVector v = new PVector(250, 250);
float sx = 3;
float sy = 2;
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  ellipse(v.x , v.y, 50, 50);
  v.x+=sx;
  v.y+=sy;
  if (v.x > 475 || v.x < 25){
    sx = -sx;
  }
  if (v.y > 475 || v.y < 25){
    sy = -sy;
  }
  
  else if ( dist(mouseX, mouseY, v.x, v.y) < 25 ){
    println("yeet");
  }
}

```
***
### 4.2 a 
```JAVA
String s1 = "yeet";
String s2 = "Yeet";
String s3 = "yeet";
void setup(){
  size(500, 500);
    background(69);
    if (s1.equals(s3)){
    println("True");
  }
}
```
***
### 4.2 b
```JAVA
String m = "Perry Otter";
void setup(){
  size(500, 500);
    background(69);
    print(m.substring(6));
}
```
***
### 4.2 c
```JAVA
String p = "Perry Otter";
String q = "perry otter";
void setup(){
  size(500, 500);
    background(69);
    if (p.toLowerCase().equals(q)){
    println("True");
  }
}
```
***
### 4.2 d
```JAVA
String n1 = "Anakin Skywalker";
String n2 = "Luke Skywalker";
String s1;
String s2;
void setup(){
  for (int i = 0; i < n1.length(); i++){
    if ( n1.substring(i, i+1).equals(" ") ){
      s1 = n1.substring(i);
    }
  }
  for (int i = 0; i < n2.length(); i++){
    if ( n2.substring(i, i+1).equals(" ") ){
      s2 = n2.substring(i);
    }
  }
  if (s1.equals(s2)){
    print("Gleiche Familie");
  }
}
```
***
### 4.2 e
```JAVA
String s = "Wanze";
int l = s.length();
void setup(){
  size(500, 500);
  textSize(30);
}
void draw(){
  background(69);
  text(s, 200, 200);
}
void mousePressed(){
  if (l == 0){
    s = "Wanze";
    l = s.length();
  }
  else{
    l--;
    s = s.substring(0, l);
  }
}
```
***
