Java Processing 2.4 - 2.5

# Java Processing 2.4
### 29.08.21
### 2.4 a
```
int x = 0;
void setup(){
  size(500, 500);
}

void draw(){
  background(69);
  ellipse(x, 50, 100, 100);
}

void mousePressed(){
  x = x+5;
}
```
****
### 2.4 b
```
int size = 0;
void setup(){
  size(500, 500);
  rectMode(CENTER);
}

void draw(){
  background(69);
  rect(250, 250, size+100, size+100);
}

void mousePressed(){
  size = size+5;
}

void keyPressed(){
  size = size-5;
} 
```
***
c übersprungen weil d sehr ähnlich ist
### 2.4 d
<div style="width: 200px;">

![redAndWhite.gif](../../_resources/0c31dd2471314ee39729e676dadc687a.gif)
</div>

```
int x = 0;
int bColor = 0;
void setup(){
  size(500, 500);
}

void draw(){
  background(bColor);
  fill(200, 0, 0);
  ellipse(x, 250, 100, 100);
  x = x+5;
  
  if (x > 500){
    x = x -500;
  }
}

void mousePressed(){
  bColor = 255;
}

void keyPressed(){
  bColor = 0;
}
```
***
### 2.4 e
```
int x = 0;
int y = 250;
void setup(){
  size(500, 500);
}

void draw(){
  background(69);
  fill(200, 0, 0);
  ellipse(x, y, 100, 100);
  x = x+5;
  
  if (x > 500){
    x = x -500;
  }
}

void mousePressed(){
  y = y +5;
}

void keyPressed(){
  y = y -5;
}
```
***
### 2.4 f
<div style="width: 200px;">

![planets.gif](../../_resources/0208cca9c7614b0f98c2d395d5724ff1.gif)
</div>

```
int radius = 25;
int movement = 0;

void setup() {
  size(500,500);
  strokeWeight(3);
  translate(250, 250);
  
}

void draw() {
  background(69);
  
  fill(70, 100, 60);
  ellipse(250, 250, 50, 50);
  fill(0, 0, 0, 0);
  float y = height/2 -cos(radians(movement)) * 150;
  float x = height/2 + sin(radians(movement)) * 150;
  movement ++;
  
  fill(50, 0, 200);
  ellipse(x, y, 30, 30);
  float y2 = y -cos(radians(movement*5)) * 50;
  float x2 = x + sin(radians(movement*5)) * 50;
  
  fill(200, 0, 0);
  ellipse(x2, y2, 30, 30);
}
```
***
### 2.4 g
<div style="width: 200px;">

![speed.gif](../../_resources/bf2febb90b56466b90d5dc138a2a6ae5.gif)
</div>

```
int radius = 25;
int x = 0;
int v = 2;

void setup() {
  size(500,500);
  strokeWeight(3);
  translate(250, 250);
}
void draw() {
  background(69);
  fill(0, 200, 0);
  ellipse(x, 250, 50, 50);
  x = x+v;
  
  if (x > 500){
    x = 0;
  }
}
void mousePressed(){
  v = v+5;
}
void keyPressed(){
  v = 2;
}
```
***
***
### 2.5 a
<div style="width: 200px;">

![twins.gif](../../_resources/f4c175e45aea4a32ad523a7d74578eae.gif)
</div>

```
void setup(){
  size(500, 500);
  
}

void draw(){
  background(69);
  
  fill(255);
  ellipse(mouseX, mouseY, 50, 50);
  
  fill(0);
  ellipse(width-mouseX, height-mouseY, 50, 50);
}
```
***
### 2.5 b
```
void setup(){
  size(500, 500);
  
}

void draw(){
  background(69);
  
  fill(255);
  line(0, 0, mouseX, mouseY);
  ellipse(mouseX, mouseY, 50, 50);
  ellipse(mouseX/2, mouseY/2 , 50, 50);
}
```
***
### 2.5 c
<div style="width: 200px;">

![miniverse.gif](../../_resources/d550586bdf754828928b8306de2e3517.gif)
</div>
Der Faktor 0.3 rechnet alle Werde im Breich 500x500
zu 150*150, also der Größe der Minimap um

$$
500*x=150 |:500 \\
x = 0.3
$$

```
// Position/Größe des Rechtecks
float x = 300;
float y = 300;
float w = 150;
float h = 150;

void setup() {
  size(500, 500);
}

void draw() {
  background(0);
  stroke(255);
  noFill();
  rect(x, y, w, h);
  fill(255);
  ellipse(mouseX, mouseY, 10, 10); // Mauszeiger
  
  fill(255);
  ellipse(mouseX*0.3+300, (mouseY*0.3)+300, 5, 5);
}
```
***
### 2.5 d
<div style="width: 200px;">

![pillars.gif](../../_resources/efb7bb95329f41e8b5442fdc2a8d22b2.gif)
</div>

```
float x = 300;
float y = 300;
float w = 150;
float h = 150;

void setup() {
  size(500, 500);
}

void draw() {
  background(69);
  
  fill(0);
  rect(-25, width-mouseY, 150, 500);
  rect(175, width-mouseY, 150, 500);
  rect(375, width-mouseY, 150, 500);
  
  fill(50, 0, 200);
  rect(100, mouseY, 100, 500);
  rect(300, mouseY, 100, 500);
  
}
```
***
