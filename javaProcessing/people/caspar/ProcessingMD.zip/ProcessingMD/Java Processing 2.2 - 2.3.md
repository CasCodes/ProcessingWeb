Java Processing 2.2 - 2.3

# Java Processing 2.2
### 28.08.21
### 2.2 a
<div style="width: 200px;">

![randomRect.gif](../../_resources/ba53fe7061e44102b08bd6174e7a9f0e.gif)
</div>

```
void setup(){
  size(500, 500);
  rectMode(CENTER);
  background(69);
}

void draw(){
}

void mousePressed(){
  fill(random(255));
  rect(random(500), random(500),random(5, 41) ,random(5, 41));
} 

```
***
### 2.2 b
<div style="width: 200px;">

![rainbow.gif](../../_resources/c19f0cb206574a408e99071c625aacfe.gif)
</div>

```
void setup(){
  size(500, 500);
  background(69);
}

void draw(){
}

void mousePressed(){
  background(0, 200, 0);
} 

void keyPressed(){
  background(200,0 ,0);
} 

```
* * *
### 2.2 c
<div style="width: 200px;">

![heckermanText.gif](../../_resources/cf2ea01e8230445399bb1549795c40e2.gif)
</div>

```
void setup(){
  size(500, 500);
  background(69);
  textSize(69);
  textAlign(CENTER);
}

void draw(){
  background(69);
  text("heckerman", mouseX, mouseY);
}

```
* * *
### 2.2 d
<div style="width: 200px;">

![pewpew.gif](../../_resources/f053aee080d748618a5c52ceccb2d9dd.gif)
</div>

```
void setup(){
  size(500, 500);
  background(69);
  textAlign(CENTER);
}

void draw(){
}

void mousePressed(){
  fill(random(255));
  textSize(random(5, 31));
  text("+", random(500), random(500));
}
```
* * *
### 2.2 e
<div style="width: 200px;">

![colorFlow.gif](../../_resources/b00519d234374b5f90dde438343a66c3.gif)
</div>

```
void setup(){
  size(500, 500);
  background(69);
  colorMode(HSB, 360, 100,100);
}

void draw(){
  background((mouseX*0.72), 69, 69);
}

```
### 2.2 f
<div style="width: 200px;">

![colorOnClick.gif](../../_resources/b537c0039b6f4992b28562230852bf1f.gif)
</div>

```
void setup(){
  size(500, 500);
  background(69);
  colorMode(HSB, 360, 100,100);
}

void draw(){
}

void mousePressed(){
  background(random(360),mouseX*0.72, 69);
}
```
***

***
### 2.3 a

```
void setup(){
  size(500, 500);
  background(69);
  colorMode(HSB, 360, 100,100);
}

void draw(){
  byte x = 10;
  byte y = 10;
  rect(x, y, 30, 30);
  
  x = 50;
  y = 50;
  rect(x, y, 30, 30);
}
```
* * *
### 2.3 b

<div style="width: 200px;">

![smiley.gif](../../_resources/1c628c86b9cf4e21be123839ab8c1827.gif)
</div>

```
void setup(){
  size(500, 500);
}


void draw(){
  float x = mouseX;
  float y = mouseY;
  
  background(69);
  
  ellipseMode(CENTER);
  //Kopf
  fill(200, 200, 0);
  ellipse(x, y, 200, 200);
  //Augen
  ellipse(x-40, y-20, 30, 30);
  ellipse(x+40, y-20, 30, 30);
  //Mund
  arc(x, y, 150, 100, radians(0), radians(180));
}

```
* * *
### 2.3 c
```
void draw(){
  float muesliGroesse1 = 700;
  float muesliPreis1 = 3.99; 

  float muesliGroesse2 = 500;
  float muesliPreis2 = (muesliPreis1/muesliGroesse1) * muesliGroesse2;

  println(muesliPreis2);
}

```
* * *
### 2.3 d
```
float x = 69;
float y = 420;

void setup(){
  size(500, 500);
}

void draw(){
  background(69);  
  
  line(x, y, mouseX, mouseY);
  println("x= "+sqrt((sq(x) + sq(mouseX))) + " y= "+ sqrt(sq(y) + sq(mouseY)));
}
```
***
### 2.3 e
```
void setup(){
  size(500, 500);
}

void draw(){
  background(69);  
  int x = mouseX;
  int y = mouseY;
  println("x= "+ (x) + " y= "+(y));
}

```
***
-> 2.2 f: er bewegt sich  jedes Mal, wenn x eine ganze Zahl erreicht
### 2.3 g
```
String message = "la";

void setup() {
  println(message);
}

void draw() {
  
}

void mousePressed(){
  message = message + "la";
  println(message);
}
```
***
 2.2 h übersprungen, weil man es für 2.2 i sowieso braucht
 ### 2.3 i
```
int bColor = 0;
int fColor = 255;

void setup() { 
  size(200, 200);
}

void draw() {
  background(bColor);
  fill(fColor);
  ellipse(100, 100, 50, 50);
}

void mousePressed(){
  bColor = 0;  
  fColor = 255;
}

void keyPressed(){
  bColor = 255;
  fColor = 0;
}
```
***
### 2.3 j
```
float posX = 100;
float posY = 100;

void setup() { 
  size(200, 200);
}

void draw() {
  background(69);
  ellipse(posX, posY, 50, 50);
}

void mousePressed(){
  posX = random(200);
  posY = random(200);
}
```
***