Java Processing 6.3

# Java Processing 6.3
### 10.10.21
### 6.3 a
![6_3a.png](../../_resources/bcca60b2927943ea82d1957a97221d14.png)
```JAVA
String[] namen = {
  "Max Schmidt", "Lisa Marx", "Robin Meier",
  "Lara Huber", "Anna Groß", "Heribert Lehmann",
  "Harry Potter", "Obi-wan Kenobi", "Julia Kron"
};
int[] alter = {
  33, 28, 12,
  22, 23, 64,
  16, 102, 18
};
boolean[] weiblich = {
  false, true, false,
  true, true, false,
  false, false, true
};

int frauen = 0;
int u40 = 0;
int male30 = 0;

for (int i = 0; i<namen.length; i++){
  if (weiblich[i] == true){
    frauen++;
    //println("Frau " + namen[i]);
  }
  else if (alter[i] < 40){
    u40++;
  }
  else if (weiblich[i] == false && alter[i]>30){
    male30++;
  }
}
print(frauen+" frauen\n", u40+" u40\n", male30+" männlich ü30\n");
```
***
### 6.3 b
<div style="width: 150px">

![6_3b.gif](../../_resources/c922ca13b3644e58b35ce5d2e7ea182e.gif)
</div>

```JAVA
int [] xpos = new int[10];
int [] ypos = new int[10];
int [] r = new int[10];
int [] g = new int[10];
int [] b = new int[10];
int [] xspeed = new int[10];
int [] yspeed = new int[10];

void setup(){
  size(500, 500);
	//fill arrays
  for (int i = 0; i<xpos.length; i++){
    xpos[i] = int(random(width));
    ypos[i] = int(random(height));
    r[i] = int(random(255));
    g[i] = int(random(255));
    b[i] = int(random(255));
    while (xspeed[i] == 0){
      xspeed[i] = int(random(-3, 3));
    }
    while (yspeed[i] == 0){
      yspeed[i] = int(random(-3, 3));
    }
  }
}

void draw(){
  background(0);
  for (int i = 0; i<xpos.length; i++){
    fill(r[i], g[i], b[i]);
    ellipse(xpos[i], ypos[i], 20, 20);
    xpos[i]+=xspeed[i];
    ypos[i]+=yspeed[i];
    
	  //wall collision
    if (xpos[i] > width || xpos[i]<0){
      xspeed[i] = -xspeed[i];
    }
    else if (ypos[i] > height || ypos[i]<0){
      yspeed[i] = -yspeed[i];
    }
  }
}
```
***
### 6.3 c
<div style="width: 150px">

![6_3c.gif](../../_resources/feb4d974323749208395005c658b268b.gif)
</div>

```JAVA
int [] xpos = new int[10];
int [] ypos = new int[10];
int [] r = new int[10];
int [] g = new int[10];
int [] b = new int[10];
int [] xspeed = new int[10];
int [] yspeed = new int[10];
boolean [] theGrandPowerSwitch = new boolean[10];

void setup(){
  size(500, 500);
  for (int i = 0; i<xpos.length; i++){
    xpos[i] = int(random(width));
    ypos[i] = int(random(height));
    r[i] = int(random(255));
    g[i] = int(random(255));
    b[i] = int(random(255));
    while (xspeed[i] == 0){
      xspeed[i] = int(random(-3, 3));
    }
    while (yspeed[i] == 0){
      yspeed[i] = int(random(-3, 3));
    }
  }
}

void draw(){
  background(0);
  for (int i = 0; i<xpos.length; i++){
    noStroke();
    if (theGrandPowerSwitch[i] == false){
      fill(r[i], g[i], b[i], 85);
    }
    // fill with transperancy if switch pressed
    else if (theGrandPowerSwitch[i] == true){
      fill(r[i], g[i], b[i], 0);
    }
    ellipse(xpos[i], ypos[i], 50, 50);
    xpos[i]+=xspeed[i];
    ypos[i]+=yspeed[i];
    
    if (xpos[i] > width || xpos[i]<0){
      xspeed[i] = -xspeed[i];
    }
    else if (ypos[i] > height || ypos[i]<0){
      yspeed[i] = -yspeed[i];
    }
  }
}

// if true set false and vice versa
void powerButton(int num){
  num = num-1;
  if (theGrandPowerSwitch[num] == true){
    theGrandPowerSwitch[num] = false;
    print(theGrandPowerSwitch[num]);
  }
  else {
    theGrandPowerSwitch[num] = true;
    print(theGrandPowerSwitch[num]);
  }
}

// ich wollte es zuerst mit einem for loop oder so machen, aber es ging nicht
// weil key nur mit ' ' verglichen werden kann. char() geht auch nicht
void keyPressed(){
  if (key == '1'){
    powerButton(1);
  }
  else if (key == '2'){
    powerButton(2);
  }
  else if (key == '3'){
    powerButton(2);
  }
  else if (key == '4'){
    powerButton(4);
  }
  else if (key == '5'){
    powerButton(5);
  }
  else if (key == '6'){
    powerButton(6);
  }
  else if (key == '7'){
    powerButton(7);
  }
  else if (key == '8'){
    powerButton(8);
  }
  else if (key == '9'){
    powerButton(9);
  }
  else if (key == '0'){
    powerButton(10);
  }
}
```
*** 
### 6.3 d - 6.3 e
<div style="width: 150px">

![6_3d.gif](../../_resources/553bb345c2414caf85e9ef0e715aa185.gif)
</div>

```JAVA
int [] xpos = new int[10];
int [] ypos = new int[10];
int [] r = new int[10];
int [] g = new int[10];
int [] b = new int[10];
int [] xspeed = new int[10];
int [] yspeed = new int[10];
boolean [] rect = new boolean[10];

int xplayer = width/2;
int yplayer = height/2;

void setup(){
  size(500, 500);
  for (int i = 0; i<xpos.length; i++){
    xpos[i] = int(random(width));
    ypos[i] = int(random(height));
    r[i] = int(random(255));
    g[i] = int(random(255));
    b[i] = int(random(255));
    while (xspeed[i] == 0){
      xspeed[i] = int(random(-3, 3));
    }
    while (yspeed[i] == 0){
      yspeed[i] = int(random(-3, 3));
    }
  }
}

void draw(){
  background(0);
  for (int i = 0; i<xpos.length; i++){
    noStroke();
    if (rect[i] == false){
      fill(r[i], g[i], b[i], 90);
    }
    // fill with transperancy if switch pressed
    else if (rect[i] == true){
      fill(r[i], g[i], b[i], 0);
    }
    ellipse(xpos[i], ypos[i], 50, 50);
    xpos[i]+=xspeed[i];
    ypos[i]+=yspeed[i];
    
    if (xpos[i] > width || xpos[i]<0){
      xspeed[i] = -xspeed[i];
    }
    else if (ypos[i] > height || ypos[i]<0){
      yspeed[i] = -yspeed[i];
    }
  
    if (keyPressed){
      if (keyCode == RIGHT && xplayer < width){
        xplayer++;
      }
      else if (keyCode == LEFT && xplayer > 0){
        xplayer--;
      }
      else if (keyCode == UP && yplayer > 0){
        yplayer--;
      }
      else if (keyCode == DOWN && yplayer < height){
        yplayer++;
      }
    }
    // collision
    if (xplayer > xpos[i]-25 && xplayer < xpos[i]+25 && yplayer > ypos[i]-25 && yplayer < ypos[i]+25){
      rect[i] = true;
    }
  }
  //player
  fill(255, 0, 0);
  ellipse(xplayer, yplayer, 30, 30);
  
  // winning screen
  boolean won = true;
  for (int i = 0; i<rect.length; i++){
    if (rect[i] == false){
      won = false;
      break;    
    }
  }
  if (won == true){
    background(0);
    textSize(20);
    text("GEWONNEN!", 200, 200);
  }
}
```
