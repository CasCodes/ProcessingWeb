Java Processing 2.6 - 2.7

# Java Processing 2.6
### 29.08.21
### 2.6 a
1)
<div style="width: 100px;">

![lines1.gif](../../_resources/0ba22f1d0a3a4620b88bad3955648882.gif)
</div>
(Das sieht so aus wegen der Framerate vom GIF)

```
int x = 0;
int y = 0;

void setup(){
  size(500, 500);
  strokeWeight(0.5);
}
void draw(){
  line(x, 0, x, y);
  x += 2;
  y++;
}
```
<div style="width: 100px;">

![lines2.gif](../../_resources/571513d61a174d9eb8cc17f7346d2b3c.gif)
</div>

2)
```
int x = 0;
int y = 0;

void setup(){
  size(500, 500);
  strokeWeight(0.5);
}
void draw(){
  line(x, 0, x, y);
  x+= 2;
  y+= 2;
}
```
<div style="width: 100px;">

![line3.gif](../../_resources/6e01fc31edb84a299c451efcc4a38443.gif)
</div>

3)
```
int x = 500;
int y = 0;

void setup(){
  size(500, 500);
  strokeWeight(1);
}
void draw(){
  stroke(0);
  line(x, 0, x, y);
  x-= 0.5;
  y++;
}
```
4)
<div style="width: 100px;">

![line4.gif](../../_resources/43131bb9f1c0458c9739a546ec85e590.gif)
</div>

```
int x = 0;
int y = 0;

void setup(){
  size(500, 500);
  strokeWeight(1);
  background(200);
}
void draw(){
  stroke(0+(x*0.4));
  line(x, 0, x, y);
  x ++;
  y ++;
}
```
***
### 2.6 b
<div style="width: 100px;">

![modulo.gif](../../_resources/f49a2e07b7ae473b8e8f773b73d7c792.gif)
</div>

```
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  ellipse(frameCount%500, 250, 100, 100);
}
```
***
### 2.6 c
<div style="width: 100px;">

![pulse.gif](../../_resources/5aa8c1c095a94bc583603970b5ec5f08.gif)
</div>

```
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  ellipse(mouseX, mouseY, frameCount%50, frameCount%50);
}
```
***
### 2.7 a
<div style="width: 100px;">

![text.gif](../../_resources/46b03cda780b4b4185b99907896bc40c.gif)
</div>

```
void setup(){
  size(500, 500);
  textSize(50);
}
void draw(){
  background(69);
  text(key, 250, 250);
}
```
***
### 2.7 b
```
void setup(){
  size(420, 69);
  textSize(50);
}
void draw(){
  ellipse(width/2, height/2, 69, 69);
}
```
***
### 2.7 c
```
void setup(){
  size(500, 500);
  textSize(50);
}
void draw(){
  background(69);
  text(frameCount/60, 250, 250);
}
void mousePressed(){
  frameCount = 0;
}
```
***
***

