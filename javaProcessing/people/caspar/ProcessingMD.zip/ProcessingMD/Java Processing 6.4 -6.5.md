Java Processing 6.4 -6.5

# Java Processing 6.4
### 18.10.2021

### 6.4 a
```JAVA
PVector [] pos = new PVector[5];
PVector [] sped = new PVector[5];

void setup(){
  background(69);
  size(500, 500);
  for (int i = 0; i<pos.length; i++){
    pos[i] = new PVector(random(500), random(500));
    sped[i] = new PVector(random(-3, 3), random(-3, 3));
  }
}

void draw(){
  background(69);
  for (int i = 0; i<pos.length; i++){
    ellipse(pos[i].x, pos[i].y, 69, 69);
    pos[i].x += sped[i].x;
    pos[i].y += sped[i].y;
    
    // collision
    if (pos[i].x < 0 || pos[i].x > 500){
      sped[i].x = -sped[i].x;
    }
    if (pos[i].y < 0 || pos[i].y > 500){
      sped[i].y = -sped[i].y;
    }
  } 
}
```
***
### 6.4 b
```JAVA
String[] text = {"ALLE", "ENTEN", "MÖGEN", "BANANEN"};
 int i = 0;

void setup(){
  size(500, 500);
  background(69);
  textSize(69);
}

void draw(){
  if (i >= text.length){
    i = 0;
  }
  background(69);
  text(text[i], width/2-69, height/2);
}
void mousePressed(){
  if (mouseButton == RIGHT){
      i++;
  }
}
```
***
### 6.4 c

<div style="width: 300px">

![6_4c.gif](../../_resources/852cded2afd74e35a652a89c55e7e506.gif)
</div>


```JAVA
PVector [] pos = new PVector[5];
PVector [] sped = new PVector[5];

PImage [] img = new PImage[5];

void setup(){
  background(69);
  size(500, 500);
  for (int i = 0; i<pos.length; i++){
    pos[i] = new PVector(random(500), random(500));
    sped[i] = new PVector(random(-3, 3), random(-3, 3));
    
    // load
    img[i] = loadImage("PP_FROGG.png");
  }
}

void draw(){
  background(69);
  for (int i = 0; i<pos.length; i++){
    image(img[i], pos[i].x, pos[i].y, 69, 69);
    pos[i].x += sped[i].x;
    pos[i].y += sped[i].y;
    
    // collision
    if (pos[i].x < 0 || pos[i].x > 500){
      sped[i].x = -sped[i].x;
    }
    if (pos[i].y < 0 || pos[i].y > 500){
      sped[i].y = -sped[i].y;
    }
  } 
}
```
***
### 6.5 a
```JAVA
int[] punktX = new int[100];
int[] punktY = new int[100];
int num = 0;

void setup() {
  size(500, 500);
  background(69);
}

void draw() {
  for (int i= 0; i < num; i++) {
    ellipse(punktX[i], punktY[i], 10, 10);
    
    if ((num % 2)==0 || num>1){
      line(punktX[num-1], punktY[num-1], punktX[num-2], punktY[num-2]);
    }
  }
}

void mousePressed() {
  punktX[num] = mouseX;
  punktY[num] = mouseY;
  num++;
}
```
***
### 6.5 b

```JAVA

int[] punktX = new int[100];
int[] punktY = new int[100];
int num = 0;

void setup() {
  ysize(500, 500);
  background(69);
}

void draw() {
  for (int i= 0; i < num; i++) {
    fill(0);
    ellipse(punktX[i], punktY[i], 10, 10);
    
    // draw the line
    if ((num % 2)==0 || num>1){
      line(punktX[num-1], punktY[num-1], punktX[num-2], punktY[num-2]);
    }
  }
}

void mousePressed() {
  punktX[num] = mouseX;
  punktY[num] = mouseY;
  
  for (int i = 0; i<num; i++){
    // if you click on a point
    if (
      mouseX-10 < punktX[i] && mouseX+10 > punktX[i] &&
      mouseY-10 < punktY[i] && mouseY+10 > punktY[i]
      ){
      println(punktX[i]);
    }
  }
  num++;
}


