Java Processing 5

# Java Processing 5
### 19.09.21
### 5.1 a
```JAVA
int count = 0;
void setup(){
  while (count <= 10){
    println(count);
    count+=2;
  }
}
```
***
### 5.1 c
```JAVA
int anzahl = 3;
void setup(){
  int i = 0;
  while (i < anzahl){
    print("#");
    i++;
  }
}
```
***
### 5.1 d
```JAVA
int x = 10;
void setup(){
  size(500, 500);
}
void draw(){
  while (x <= width-10){
    rect(x, 40, 50, 50);
    x+=60;
  }
}
```
***
### 5.1 e
```JAVA
int num = 0;
while(num < 49){
  if (num % 7 == 0 || num % 13 == 0){
    println(num);
  }
  num++;
}
```
***
***
### 5.2 a
```JAVA
for (int i = 0; i<=10; i+=2){
  println(i);
}
```
***
### 5.2 c
```JAVA
int anzahl = 3;
for (int i = 0; i<anzahl; i++){
  print("#");
}
```
***
### 5.2 d
```JAVA
int anzahl = 10;
for (int i = 0; i<anzahl; i++){
  if (i%2 == 0){
    print("#");
  }
  else{
    print(".");
  }
}
```
***
### 5.2 e
<div style="width: 200px;">

![verticalLines.png](../../_resources/fbce5146da154cadab4cc9f395fe71b0.png)
</div>

```JAVA
size(500, 500);
for (int i = 0; i<height; i+=10){
  line(0, i, 500, i);
}
```
***
### 5.2 f
```JAVA
int sum = 0;
int n = 4;
for (int i = 1; i<=n; i++){
  sum+=i;
}
println(sum);
```
***
### 5.2 g
```JAVA
int sum = 1;
int n = 3;
for (int i = 1; i<=n; i++){
  sum = sum*i;
}
println(sum);
```
***
### 5.2 h 
```JAVA
int n = 4;
int sum = 1;
for (int i = 1; i<=n; i++){
  sum = i*2;
  println(i, sum);
}
```
***
### 5.2 i
```JAVA
float f;
for (int i = 0; i <= 10; i++){
	//Fibonacci Formel
  f = (1/ sqrt(5))* (pow(((1+sqrt(5))/2), i) - pow(((1-sqrt(5))/2), i));
  print(int(f) + " ");
}
```
***
### 5.2 j
<div style="width: 150px;">

![dotGraph.png](../../_resources/d3818aa07e59484598a48be22f99db61.png)
</div>

```JAVA
void setup(){
  size(500, 500);
  strokeWeight(10);
}
void draw(){
  translate(0, 500);
  for(int x = 0; x<500; x+=22){
    point(x, -pow(x/22, 2));
  }
}
```
***
### 5.2 k
<div style="width: 150px;">

![spiral.png](../../_resources/52287b6756ba45f0818911d52ceb197e.png)
</div>

```JAVA
float deg = 25;
int rad = height/8;
void setup() {
  size(500,500);
  strokeWeight(20);
  translate(250, 250);
  background(69);
  
}

void draw() {
  fill(0, 0, 0, 0);
  while(rad<212){
  //*0.72 um mouseY in Teile von 360 umzuwandeln * 200 für länge
    float y = rad * cos(radians(deg*0.72)) + 250;
    float x = rad * sin(radians(deg*0.72)) + 250;
    deg+=12;
    rad++;
    point(x, y);
  }
}
```
***
***
### 5.3 a
<div style="width: 150px;">

![circleMouse.gif](../../_resources/59832733208348dba411e522bc007536.gif)
</div>

```JAVA
int amount = 4;
void setup(){
  size(500, 500);
}

void draw(){
  background(69);
  for (int i = 0; i < amount; i++){
    noFill();
    ellipse(mouseX, mouseY, 30+(10*i), 30+(10*i));
  }
}
```
***
### 5.3 b
<div style="width: 150px;">

![dotline.gif](../../_resources/3be138e188864b4c8ba48a892ac1c144.gif)
</div>

```JAVA
void setup(){
  size(500, 500);
  strokeWeight(5);
}

void draw(){
  background(69);
  for (int i = 0; i < mouseX; i+=10){
    point(i , mouseY);
  }
}
```
***
### 5.3 c
<div style="width: 150px;">

![dotMatrix.gif](../../_resources/573e92424ff941ebb5febc0da5ebe76e.gif)
</div>

```JAVA
void setup(){
  size(500, 500);
  strokeWeight(5);
}
void draw(){
  background(69);
  for (int i = 0; i < mouseX; i+=10){
    for (int j = 0; j < mouseY; j+=10){
      point(i, j);
    }
  }
}
```
***
### 5.3 d
<div style="width: 150px;">

![forLines.gif](../../_resources/d89d2005047a45f68ac0464cbd256604.gif)
</div>

```JAVA
float j = 1;
void setup(){
  size(500, 500);
  strokeWeight(5);
}
void draw(){
  background(69);

  for (int i = 0; i < height; i+=40){
    line(0, j+i, width, j+i);
    j+=0.1;
    if (j > 40){
      j = 0;
    }
  }
}
```
***
### 5.3 e
<div style="width: 150px;">

![blockCluster.gif](../../_resources/569662f6ead84c6595923b65e76b1f0e.gif)
</div>

```JAVA
int num = 5;
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  for (int i = 0; i < num; i++){
     for (int j = 0; j < num; j++){
       noFill();
       rect(mouseX+(20*i), mouseY+(20*j), 20, 20);
     }
  }
}
```
***
### 5.3 f
<div style="width: 150px;">

![forCircles.gif](../../_resources/db1ed9ee03b84f9687895b3367433b37.gif)
</div>

```JAVA
int num = 1;
void setup(){
  size(500, 500);
}
void draw(){
  background(69);
  noFill();
  int r = 50;
  for (int i = 0; i < num; i++){
    ellipse(250, 250, r, r);
    r+=20;
  }
}
void mousePressed(){
  if (mouseButton == LEFT){
     num+=1;
  }
  else if (mouseButton == RIGHT && num > 1){
    num-=1;
  }
}
```
***
***
### 5.4 a
```JAVA
for (int i = 1; i < 11; i++){
  println(" Die "+i+"er-Reihe");
    
  for (int j = 1; j < 11; j++){
     println(i+" x "+j+" ist "+(i*j));
  }
}
```
***
### 5.4 b
```JAVA
for (int i = 0; i < 3; i++){
  for (int j = 0; j< 5; j++){
    print("#");
  }
  print("\n");
}
```
***
### 5.4 c
![Screenshot_20210925_160550.png](../../_resources/b6df1e833cf84335a375ee6fa99db377.png)
```JAVA
int size = 4;
for (int h = 0; h < size; h++){
  for (int w = -h; w < 0; w++){
    print(".");
  }
  print("#"); 
  
  for (int w = h; w < size-1; w++){
    print(".");
  }   
  print("\n");

}
```
***
### 5.4 d
![Screenshot_20210925_160902.png](../../_resources/56a423c3d86040cfa2e528eeb494250b.png)
```JAVA
int size = 4;
for (int h = 0; h < size; h++){
  for (int w = -h; w < 0; w++){
    print(".");
  }
  for (int w = h; w < size; w++){
    print("#");
  }   
  print("\n");
}
```
***
### 5.4 e
![Screenshot_20210925_154753.png](../../_resources/75a49bab25ad4938b0bb29f3f8a9f942.png)
```JAVA
int i = 4;
for (int h = 0; h < i; h++){
  for (int w = h; w < i-1; w++){
    if ( i > 1){
      print(".");
    }
  }
  for (int w = -h; w < 1; w++){
    print("#");
   }
   print("\n");
}
```
***
### 5.4 f
![Screenshot_20210925_162052.png](../../_resources/25a7da76bc054250b5e9b3df3ec97387.png)
```JAVA
int i = 4;
rectMode(CENTER);

size(500, 500);
for (int y = 0; y < i; y++){
  fill(0);
  rect(210, y*(10*i) +250, 30, 30);
  
  for (int x = 0; x < i-1; x++){
    fill(255);
    ellipse(x*(10*i) +250, y*(10*i) +250, 30, 30);
  }
}
```
***
### 5.4 g


```JAVA
int c = 0;
size(500, 500);
for (int i = 0; i < 4; i++){ 
  
  for (int j = 0; j < 4; j++){
    
    if (i%2 == 0 && j%2 == 0 || i%2 != 0 && j%2 != 0){
      c = 0;
      fill(c);
      rect(i*125, j*125, 125, 125);
    }
        if (i%2 != 0 && j%2 == 0 || i%2 == 0 && j%2 != 0){
      c = 255;
      fill(c);
      rect(i*125, j*125, 125, 125);
    }
   
  }
}
```
***
### 5.4h
<div style="width: 150px">

![Screenshot_20210926_123534.png](../../_resources/d811fc9d28f6450492621fe7ea11132a.png)
</div>

```JAVA
float deg =12;
int rad = 100;
void setup() {
  size(500,500);
  strokeWeight(20);
  translate(250, 250);
  background(69);
}
void draw() {
  fill(0, 0, 0, 0);
  for (int i = 0; i < 3; i++ ){
    float y = rad * cos(radians(deg*0.72)) + 250;
    float x = rad * sin(radians(deg*0.72)) + 250;
    deg+=150;
    rad = 100*i;
    point(x, y);
  }
}
```