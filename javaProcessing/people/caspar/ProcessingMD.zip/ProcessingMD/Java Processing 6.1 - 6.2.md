Java Processing 6.1 - 6.2

# Java Processing 6
### 26.09.21

### 6.1 a
![Screenshot_20210926_225721.png](../../_resources/23d756f3c03d452c94e0c67e26ac3e0c.png)
```JAVA
int[] i = {69, 420, 42};
String[] s = {"may", "stackoverflow", "be", "with", "you"};
float[] f = {420.69, 69.420,};
boolean[] b = {true, true, false};
println(b);
print(f); //<-- Ist der output hexadecimal? <datatyp>@<memory location> ? warum?
```
***
### 6.1 b
```
int[] foo = {5, 45, -10, 20};
int a = foo[0] + foo[1];
int b = foo[2] + foo[3];
print(a, b);
```
***
### 6.1 c
```
int[] bar = {2, 4, 6};
bar[2] = bar[0]*bar[1];
println(bar);
```
***
### 6.2 a
```JAVA 
int steps = 1;
int start = 1;

int[] a = new int[(start+10)*steps];
void setup(){
  for (int i = start; i<a.length; i+=steps){
    a[i] = i;
    print(a[i]+" ");
  }
}
```
***
### 6.2 b

<div style="width: 150px">

![6_2b.png](../../_resources/4e9bc37fd403474da39a50552a2129a7.png)
</div>

```JAVA
int f[] = new int[10];

f[0] = 1;
f[1] = 1;
for (int i=2; i<10; i++){
  f[i] = f[i-2] + f[i-1];
}
println(f);
```
***
### 6.2 c
<div style="width: 150px">

![6_2c.png](../../_resources/cc917d3b7b234bfb9b1fffee7990012b.png)
</div>

```JAVA
int a[] = new int[10];
int b[] = new int[10];

for (int i=0; i<10; i++){
  a[i] = i+1;
  b[i] = i-10;
}
println(b);
```
***
### 6.2 d
![6_2d.png](../../_resources/45e83952a6dd44849c5bc47c07fa1d28.png)
```JAVA
int[] a  = { 2, 1, 3, 5 };

for (int i=0; i<a.length; i++){
  a[i] = a[i]*2;
}
println(a);
```
***
### 6.2 e
```JAVA
int[] foo = { 22, -10, 8, 10 };
int sum = 0;

for (int i = 0; i<foo.length; i++){
  sum+=foo[i];
}
print(sum);
```
***
### 6.2 f
```JAVA
int[] a  = { 1, -2, -25, 6, -3, 5 };

for (int i = 0; i<a.length; i++){
  if (a[i] < 0){
    println(a[i]);
  }
}
```
***
### 6.2 g
```JAVA
int[] a  = { 1, 2, 25, 6 };
int[] b  = { 9, 18, 5, 34 };
int[] c = new int[4];

for (int i = 0; i<a.length; i++){
  c[i] = a[i]+b[i];
}
println(c);
```
***
### 6.2 h
![6_2h.png](../../_resources/185edd0b850e4718b6142e0fb52831b4.png)
```JAVA
int[] a  = { 1, 2, 25 };
int[] b  = { 9, 18 };
int[] c = new int[a.length+b.length];

for (int i = 0; i<a.length; i++){
  c[i] = a[i];
}
for (int i = 0; i<b.length; i++){
  c[i+a.length] = b[i];
}
println(c);
```
***
### 6.2 i
![6_2i.png](../../_resources/237baccb77e8433e90135fe54cd605e9.png)
```JAVA
int[] foo = { 1, 2, 3, 4 };
int[] rev = new int[foo.length];

for (int i = 0; i<foo.length; i++){
  rev[i] = foo[foo.length-i-1];
}
println(rev);
```
***
### 6.2 j

```JAVA
int[] foo = { 10, 20, 30, 40, 50 };

for (int i = foo.length-1; i>0; i--){
  foo[i] = foo[i-1];
}
println(foo);
```
***
### 6.2 k
![6_2k.png](../../_resources/83796fd57bd04d42bc7cca54e0967bad.png)
```JAVA
int[] foo = { 1, 2, 3, 4, 5, 6 };
int[] bar = new int[foo.length/2];

for (int i = 1; i<foo.length; i+=2){
  bar[i/2] = foo[i] + foo[i-1];
}
println(bar);
```
***
### 6.2 l
	1) Feststellen, ob mindestens eine 
	Person infiziert ist
	
```JAVA

boolean[] inf = new boolean[10];

// Array random befüllen
for (int i = 0; i < inf.length; i++) {
  int p = int(random(100));
  if (p <=5 ){
    inf[i] = true;
  }
  else {
    inf[i] = false;
  }
}
println(inf); // Kontrolle
// Feststellen, ob jemand infiziert ist
boolean alarm = false;
for (int i = 0; i<inf.length; i++){
  if (inf[i] == true){
    println("ALARM");
    alarm = true;
    break;
  }
}
if (alarm == false){
  print("KEIN PROBLEM");
}
```

	2) Feststellen, ob alle infiziert sind

<div style="width: 100px">

![6_2l.png](../../_resources/91dbc439b24e406596863820202d3276.png)
</div>

```JAVA
boolean[] inf = new boolean[10];

for (int i = 0; i < inf.length; i++) {
  int p = int(random(100));
  
  if (p <=95 ){
    inf[i] = true;
  }
  else {
    inf[i] = false;
  }
}
println(inf); // Kontrolle

boolean alarm = true;
for (int i = 0; i<inf.length; i++){
  if (inf[i] == false){
    println("nicht alle");
    alarm = false;
    break;
  }
}
if (alarm == true){
  print("alle");
}
```
***
