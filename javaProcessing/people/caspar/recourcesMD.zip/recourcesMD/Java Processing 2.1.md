Java Processing 2.1

# Java Processing 2.1
### 25.08.21
### 2.1 b

x-Position des Cursors

```
void draw(){
   int x = mouseX;
   println(x);
}
```

### 2.1 c

Linie die von P(0|0) ausgehend dem Cursor folgt

```
void draw(){
  background(69);
  
  strokeWeight(5);
  line(0, 0, mouseX, mouseY);
}
```
* * *
### 2.1 d

Je nach X-Position des Cursors wird die Größe des Quadrats verändert
<div style="width: 200px;">

![BlueRect.gif](../../_resources/2829ac2686864ddc889fe2e725b973c9.gif)
</div>

```
void setup(){
  
  size(500, 500);
  rectMode(CENTER);
  strokeWeight(3);
}

void draw(){
  background(69);
  
  int size = mouseX;
  fill(0, 0, 69);
  rect(250, 250, size, size);
}
```
* * *
### 2.1 e
Fadenkreuz, dass den Mittelpunkt beim Cursor hat.
<div style="width: 200px;">

![crosshair.gif](../../_resources/9ff94980761441e18a5e40e4e4974f29.gif)
</div>

```
void setup(){
  
  size(500, 500);
  strokeWeight(3);
}

void draw(){
  background(69);
  
  line(-height, mouseY, height, mouseY);
  line(mouseX, -width, mouseX, width);
}
```
* * *
### 2.1 f
<div style="width: 200px;">

![CircleLine.gif](../../_resources/63e11ae6baa24bbdab47b65fc0d0593d.gif)
</div>

```
void setup(){
  
  size(500, 500);
  strokeWeight(3);
}

void draw(){
  background(69);
  
  line(mouseX, -width, mouseX, width);
  ellipse(mouseX/2, height/2, mouseX, mouseX);
}
```
* * *
### 2.1 g
Blaues Quadrat wird an der Position des Cursors "raddiert"

<div style="width: 200px;">

![eraser.gif](../../_resources/8aeff2978836477c884f7c00a0ccd922.gif)
</div>

```
void setup(){
  
  size(500, 500);
  
  background(69);
  
  fill(0, 0, 76);
  rect(50, 50, 400, 400);
  
}

void draw(){

  noStroke();
  fill(75);
  ellipse(mouseX, mouseY, 15, 15);
  
  
}
```
* * *
### 2.1 h
<div style="width: 200px;">

![SymmetricLine.gif](../../_resources/2dec9069c4934aaf94a8fcc22cd3648b.gif)
</div>

```
void setup(){
  
  size(500, 500);
  strokeWeight(3);
}

void draw(){
  background(69);
  
  line(mouseX, mouseY, width-mouseX, height-mouseY);
}
```

* * *
### 2.1 i
<div style="width: 200px;">

![Square.gif](../../_resources/88cf066840ff413b8acb3efa68691542.gif)
</div>

```
void setup(){
  
  size(500, 500);
  strokeWeight(3);
  rectMode(CORNERS);
}

void draw(){
  background(69);
  rect(mouseX, mouseY, width-mouseX, height-mouseY);
}
```
***
### 2.1 j
<div style="width: 200px;">

![Kreis.gif](../../_resources/e4261da86c0642089e0fa6b37d80244a.gif)
</div>

```
void setup(){
  
  size(500, 500);
  strokeWeight(3);
  ellipseMode(RADIUS);
}

void draw(){
  background(69);
  float ellipseRad = sqrt(sq(mouseX)+sq(mouseY));
  ellipse(0, 0, ellipseRad, ellipseRad);
}
```
* * *
### 2.1 k
<div style="width: 200px;">

![Graustufen.gif](../../_resources/5d1833c4bb53492b9b959bf25397b0c2.gif)
</div>

```
void setup(){
  size(500, 500);
  noStroke();
}

void draw(){
  background(255);
  fill(mouseX);
  rect(50, 50, 400, 400);
}
```
* * *
### 2.1 L

<div style="width: 200px;">

![Radians.gif](../../_resources/40203b65a62b4e6ba01726e5b7f013b3.gif)
</div>

```
void setup(){
  size(500, 500);
}

void draw(){
  background(69);
  fill((420-69)/4-18,75);

  arc(250, 250, 400, 400, 0, radians(mouseX*360/width));
  
}
```
* * *
###  2.1 m
<div style="width: 200px;">

![clock.gif](../../_resources/c0f82cb1eda9433dbb297b9066cff6da.gif)
</div>
Zuerst habe ich mich nur auf die Y-Koordinate fokussiert.
Nach einigem Überlegen und Ausprobieren, bin ich auf folgende funktion gekommen:

$$ 
y = 500/2 -cos(radians(mouseY*0.72)) * 200 
$$
500 bezieht sich auf die Höhe des Feldes und 0.72 ist ein Faktor um alle
Y-Werte (0-500) in Werte zwischen 0-360 umzuwandeln, da ein Kreis 360 Grad hat. 
Um diesen Faktor herauszufinden habe ich eine Gleichung aufgestellt:
$$
500*a = 360 |:500 \\
a = 0,72
$$

```
void setup() {
  size(500,500);
  strokeWeight(3);
  translate(250, 250);
  
}

void draw() {
  background(69);
  
  fill(0, 0, 0, 0);
  ellipse(250, 250, 400, 400);
  
  //-cos damit der Zeiger oben anfängt, 
  //*0.72 um mouseY in Teile von 360 umzuwandeln * 200 für länge
  float y = height/2 -cos(radians(mouseY*0.72)) * 200;
  float x = height/2 + sin(radians(mouseY*0.72)) * 200;
  
  line(250, 250, x, y);

}

```
* * *
habe n) und o) übersprungen, weil es das selbe Prinzip wie von p) ist
### 2.1 p
<div style="width: 200px;">

![stamp.gif](../../_resources/d924167022354be4a462a9601e33ebb1.gif)
</div>

```
void setup(){
  size(500, 500);
  rectMode(CENTER);
  background(69);
}

void draw(){
}

void mousePressed(){
  rect(mouseX, mouseY, 50, 50);
} 
```
* * *
### 2.1 q
```
void setup(){
  size(500, 500);
  rectMode(CENTER);
  background(69);
}

void draw(){
}

void mousePressed(){
  background(0, 200, 0);
} 

void keyPressed(){
  background(200,0 ,0);
} 

```
* * *