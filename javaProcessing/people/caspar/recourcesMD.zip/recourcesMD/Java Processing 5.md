Java Processing 5

# Java Processing 5
### 19.09.20
### 5.1 a
```JAVA
int count = 0;
void setup(){
  while (count <= 10){
    println(count);
    count+=2;
  }
}
```
***
### 5.1 c
```JAVA
int anzahl = 3;
void setup(){
  int i = 0;
  while (i < anzahl){
    print("#");
    i++;
  }
}
```
***
### 5.1 d
```JAVA
int x = 10;
void setup(){
  size(500, 500);
}
void draw(){
  while (x <= width-10){
    rect(x, 40, 50, 50);
    x+=60;
  }
}
```
***
### 5.1 e
```JAVA
int num = 0;
while(num < 49){
  if (num % 7 == 0 || num % 13 == 0){
    println(num);
  }
  num++;
}
```
***
***
### 5.2 a
```JAVA
for (int i = 0; i<=10; i+=2){
  println(i);
}
```
***
### 5.2 c
```JAVA
int anzahl = 3;
for (int i = 0; i<anzahl; i++){
  print("#");
}
```
***
### 5.2 d
```JAVA
int anzahl = 10;
for (int i = 0; i<anzahl; i++){
  if (i%2 == 0){
    print("#");
  }
  else{
    print(".");
  }
}
```
***
### 5.2 e
<div style="width: 200px;">

![verticalLines.png](../../_resources/fbce5146da154cadab4cc9f395fe71b0.png)
</div>

```JAVA
size(500, 500);
for (int i = 0; i<height; i+=10){
  line(0, i, 500, i);
}
```
***
### 5.2 f
```JAVA
int sum = 0;
int n = 4;
for (int i = 1; i<=n; i++){
  sum+=i;
}
println(sum);
```
***
### 5.2 g
```JAVA
int sum = 1;
int n = 3;
for (int i = 1; i<=n; i++){
  sum = sum*i;
}
println(sum);
```
***
### 5.2 h 
```JAVA
int n = 4;
int sum = 1;
for (int i = 1; i<=n; i++){
  sum = i*2;
  println(i, sum);
}
```
***
### 5.2 i
```JAVA
float f;
for (int i = 0; i <= 10; i++){
	//Fibonacci Formel
  f = (1/ sqrt(5))* (pow(((1+sqrt(5))/2), i) - pow(((1-sqrt(5))/2), i));
  print(int(f) + " ");
}
```
***
### 5.2 j
<div style="width: 150px;">

![dotGraph.png](../../_resources/d3818aa07e59484598a48be22f99db61.png)
</div>

```JAVA
void setup(){
  size(500, 500);
  strokeWeight(10);
}
void draw(){
  translate(0, 500);
  for(int x = 0; x<500; x+=22){
    point(x, -pow(x/22, 2));
  }
}
```
***
### 5.2 k
<div style="width: 150px;">

![spiral.png](../../_resources/52287b6756ba45f0818911d52ceb197e.png)
</div>

```JAVA
float deg = 25;
int rad = height/8;
void setup() {
  size(500,500);
  strokeWeight(20);
  translate(250, 250);
  background(69);
  
}

void draw() {
  fill(0, 0, 0, 0);
  while(rad<212){
  //*0.72 um mouseY in Teile von 360 umzuwandeln * 200 für länge
    float y = rad * cos(radians(deg*0.72)) + 250;
    float x = rad * sin(radians(deg*0.72)) + 250;
    deg+=12;
    rad++;
    point(x, y);
  }
}
```
***
***
### 5.3 a