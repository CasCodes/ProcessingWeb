Java Processing 3.1 - 3.6

# Java Processing 3.1
### 30.08.21 - 05.09.21
### 3.1 a
```
int zahl = 23;
void setup(){
  size(10, 10);
  
  if (zahl%2 != 0){
    println("odd");
  }
  if (zahl%2 != 1){
    println("even");
  }
}
```
***
### 3.1 b
```
int zahl = 69;
int zahl2 = 420;

int zahl3 = 169;
void setup(){
  size(10, 10);
  
  if (zahl3 > zahl && zahl3 < zahl2){
    print("drin");
  }
}
```
***
### 3.1 c
```
byte note = 10;
int zahl3 = 169;
void setup(){
  size(10, 10);
  
  if (note >= 5){
    print("Bestanden");
  }
  else if (note < 5){
    println("Durchgefallen");
  }
}
```
***
### 3.1 d
<div style="width: 100px;">

![stopAtCenter.gif](../../_resources/7e0b7815742c42a89297647d7809b7bf.gif)
</div>

```
int x = 0;
byte y = 1;
void setup(){
  size(500, 500);
}

void draw() {
  background(69);
  ellipse(x, 250, 100, 100);
  x+=y;
  if (x > width/2) {
    y = 0;
  }
}
```
***
### 3.1 e
```int x = 0;
byte y = 1;
void setup(){
  size(500, 500);
}

void draw() {
  background(69);
  ellipse(250, x, 100, 100);
  x+=y;
  if (x > width/2) {
    y = 0;
  }
}
```
***
### 3.1 f
```
int x = 0;
int y = 3;
int s = 50;
void setup(){
  size(500, 500);
}

void draw() {
  background(69);
  ellipse(x, 250, s, s);
  x+=y;
  
  if (x > 500 || x < 0) {
    y = y*-1;
    s = s+10;
  }
}
```
***
### 3.1 g
<div style="width: 100px;">

![ripples.gif](../../_resources/1e05f791302c4661a14abf943a469b9f.gif)
</div>

```
int s = 0;
void setup(){
  size(500, 500);
}

void draw() {
  background(69);
  noFill();
  ellipse(250, 250,s, s);
  s+=5;
  if (s > 500){
    s = 0;
  } 
}
```
***
### 3.1 h
<div style="width: 100px;">

![mutate.gif](../../_resources/0d1205598506480ea61985a382664712.gif)
</div>

```
int s = 0;
void setup(){
  size(500, 500);
  rectMode(CENTER);
}

void draw() {
  background(69);
  if (mouseX < width/2){
    fill(255);
    ellipse(mouseX, mouseY, 100, 100);
  } 
  else if (mouseX > width/2){
    fill(0);
    rect(mouseX, mouseY, 100, 100);
  }
}
```
***
### 3.1 i
Ich wusste nicht was die hier genau wollten, aber es wird 1x pro Sekunde ein Punkt geprinted.
```
void setup(){
}
void draw(){
  frameRate(1);
  print(".");
}
```
***
### 3.1 j
```
int gewinnChance = 20; //Gewinnchance in Prozent
void draw() {
}
void keyPressed() {
  int num = round(random(100));
  if (num <= gewinnChance){
    println(num + " gewinnt");
  }
}
```
***
### 3.1 k
<div style="width: 100px;">

![stopwatch.gif](../../_resources/435af3472126445390d8b467af88fc3f.gif)
</div>

```
int x = 0;
void setup(){
  size(500, 500);
  strokeWeight(2);
}

void draw(){
  background(69);
  noFill();
  stroke(255);
  ellipse(250, 250, 400, 400);
  fill(250);
  
  arc(250, 250, 400, 400, -0.5*PI, radians(x*360/width)-0.5*PI);
  x+=5;
  
  if (x > 500){
    x = 0;
  }
}

```
***
### 3.2 a
```
int punkte = 0;
void setup(){
  if (punkte >= 0 && punkte <= 10){println("Durchgefallen");}
  else if (punkte > 10 && punkte <= 20){println("Naja");}
  else if (punkte > 20 && punkte <= 30){println("Mittelgut");}
  else if (punkte > 30 && punkte <= 40){println("Gut");}
  else if (punkte > 40 && punkte <= 50){println("Super");}
}
```
***
### 3.2 b
```
int zustand = 0;

void setup() {
  textAlign(CENTER);
  textSize(20);
}
void draw() {
  background(0);
  if (zustand == 0) {
    text("Hallo", width/2, height/2);
  }
  else if (zustand == 1) {
    text("mein", width/2, height/2);
  }
  else if (zustand == 2) {
    text("Name", width/2, height/2);
  }
  else if (zustand == 3) {
    text("ist", width/2, height/2);
  }
  else if (zustand == 4) {
    text("Hase", width/2, height/2);
  }
  else if (zustand == 5) {
    text("Tschüs", width/2, height/2);
  }
  else if (zustand >= 6) {
    zustand = 0;
  }
}
void mousePressed(){
  zustand++;
}
```
***
### 3.3 a
```
int a = 69;
float n = 4.2;

void setup() {
  if (a > 20 && n < 3.0){
    println("EINSTELLEN!");
  }
  else{
    println("lieber nicht");
  }
}
```
***
### 3.3 b
```
int pA = 4;
float n = 6.9;

void setup() {
  if (n == 1 || pA == 5 && n <= 3){
    println("EINSTELLEN!");
  }
  else if(n == 2 || pA == 4){
    println("EINLADEN!");
  }
  else{
    println("ABLEHNEN!");
  }
}
```
***
### 3.3 c
<div style="width: 100px;">

![pulseCircle.gif](../../_resources/b1c343d54f994e6a9d17d9c6ca5f7dfd.gif)
</div>

```
int a = 50;
int g = 2;

void setup() {
  strokeWeight(3);
  size(500, 500);
}

void draw() {
  background(69);
  ellipse(width/2, height/2, a, a);
  a += g;
  println(a);
  if (a >= width || a < 50){
    g = -g;
  }
}
```
***
### 3.3 d
```JAVA
int a = 0;
int c = 2;

void setup() {
  size(500, 500);
}
void draw() {
  background(69);
  fill(a);
  ellipse(width/2, height/2, 200, 200);
  a+=c;
  if (a > 255 || a < 0){
    c=-c;
  }
}
```
***
### 3.3 e
<div style="width: 100px;">

![redZone.gif](../../_resources/e2ca544170a34fc8a06984a31d0bb8ba.gif)
</div>

```JAVA
int a = 0;
int c = 250;

void setup() {
  size(500, 500);
  strokeWeight(3);
}
void draw() {
  background(69);
  line(350,0, 350, 500);
  line(150,0, 150, 500);
  
  fill(250, c, c);
  ellipse(a, 250, 100, 100);
  a+=2;
  if (a > width){
    a = 0;
  }
  if (a > 150 && a < 350){
    c = 0;
  }
  else{
    c = 255;
  }
}
```
***
### 3.3 f
```JAVA
int a = 0;
int c = 0;
void setup() {
  size(500, 500);
  strokeWeight(3);
}
void draw() {
  background(69);
  line(350,0, 350, 500);
  line(150,0, 150, 500);
  
  fill(250, c, c);
  ellipse(a, 250, 100, 100);
  a+=2;
  if (a > width){
    a = 0;
  }
  if (a > 150 && a < 350){
    c = 250;
  }
  else{
    c = 0;
  }
}
```
***
### 3.4 a
```
boolean foo = true;
foo = false;
println(foo);
foo = true;
println(foo);
```
### 3.4 b
```JAVA
boolean visible = true;
int c = 250;
void setup(){
  size(500, 500);
  noStroke();
}
void draw(){
  background(69);
  fill(c);
  ellipse(250, 250, 200, 200);
}

void mousePressed(){
  if (visible == true){
    c = 69;
    visible = false;
  }
  else{
    c = 250;
    visible = true;
  }
}
```
***
### 3.4 c
<div style="width: 100px;">

![rectAndCircle.gif](../../_resources/0cff365b5c2142419120ff960c7bedf3.gif)
</div>

```JAVA
boolean isSq = false;
void setup(){
  background(0);
  size(500, 500);
  rectMode(CENTER);
}
void draw(){
  if (isSq == false){
    fill(250);
    ellipse(mouseX, mouseY, 100, 100);
  }
  if (isSq == true){
    fill(0);
    rect(mouseX, mouseY, 100, 100);
  }
}
void mousePressed(){
  if (isSq == true){
    isSq = false;
  }
  else{
    isSq = true;
  }
}
```
***
### 3.4 d
<div style="width: 100px;">

![circleXY.gif](../../_resources/e42a84a0a9d547b7aaba5f2cbe4b302c.gif)
</div>

```JAVA
int x = 0;
int y = 0;
boolean horizontal = true;
void setup(){
  size(500, 500);
  rectMode(CENTER);
}
void draw(){
  background(69);
  if (horizontal){
    ellipse(x, y, 100, 100);
    x+=2;
  }
  else{
    ellipse(x, y, 100, 100);
    y+=2;
  }
  if (x == 500){
    x = 0;
  }
  else if (y == 500 ){
    y = 0;
  }
}
void mousePressed(){
  if (horizontal){
    horizontal = !horizontal;
  }
  else{
    horizontal = true;
  }
}
```
***
### 3.5 a
<div style="width: 100px;">

![drops.gif](../../_resources/38911cf567154b75893282c2c9b7da3e.gif)
</div>

```JAVA
int x = 250;
float q = 0;
float p = random(500);
float c = 255;

float q2 = 0;
float p2 = random(500);
float c2 = 255;

float q3 = 0;
float p3 = random(500);
float c3 = 255;
void setup(){
  size(500, 500);
  rectMode(CENTER);
}
void draw(){
  background(69);
  fill(255);
  rect(x, 400, 150, 30);
  if (keyPressed){
    if (keyCode == RIGHT && x < 425){
    x+=2;
    }
    else if (keyCode == LEFT && x > 75){
      x-=2;
    }
  }
  // 1st ellipse
  fill(c);
  ellipse(p, q, 50, 50);
  q+=3;
  if (q > 500){
    p = random(25, 475);
    q = random(-200, 0);
    c = random(255);
  } 
  // 2nd ellipse
  fill(c2);
  ellipse(p2, q2, 50, 50);
  q2+=3;
  if (q2 > 500){
    p2 = random(25, 475);
    q2 = random(-200, 0);
    c2 = random(255);
  } 
  // 3rd ellipse
  fill(c3);
  ellipse(p3, q3, 50, 50);
  q3+=3;
  if (q3 > 500){
    p3 = random(25, 475);
    q3 = random(-200, 0);
    c3 = random(255);
  }
  //Das ist ein unstylisher weg das zu lösen, aber es funktioniert
}
```
***
### 3.5 c
<div style="width: 100px;">

![gate.gif](../../_resources/d47fc28b7a954c7f849693cb514c0cd8.gif)
</div>

```JAVA
int y = 250;
void setup(){
  size(500, 500);
  strokeWeight(10);
}
void draw(){
  background(69);
  line(250, 0, 250, y);
  line(250, 500, 250, y+50);
  
  if (keyPressed){
    if (keyCode == UP && y > 5){
      y-=2;
    }
    if (keyCode == DOWN && y < 495 ){
      y+=2;
    }
  }
}
```
***
### 3.6 a
<div style="width: 100px;">

![rgb.gif](../../_resources/47f6de9191874fd6bc330fed3c8913b0.gif)
</div>

```JAVA
int r = 69;
int g = 69;
int b = 69;
int cr1 = 255;
int cr2 = 255;
int cr3 = 255;
void setup(){
  size(500, 500);
  rectMode(CENTER);
  textSize(35);
}
void draw(){
  background(r, g, b);
  //bad style 2.0
  fill(cr1);rect(250, 100, 200, 50);fill(0);text("rot", 250, 100);
  fill(cr2);rect(250, 200, 200, 50);fill(0);text("grün", 250, 200);
  fill(cr3);rect(250, 300, 200, 50);fill(0);text("blau", 250, 300);
  
  if (mouseX > 150 && mouseX < 350 && mouseY > 50 && mouseY < 125){
    cr1 = 169;
    if (mousePressed){
      r = 250;
      g = 0;
      b = 0;
    }
  }
  else if (mouseX > 150 && mouseX < 350 && mouseY > 175 && mouseY < 225){
    cr2 = 169;
    if (mousePressed){
      r = 0;
      g = 250;
      b = 0;
    }
  }
  else if (mouseX > 150 && mouseX < 350 && mouseY > 275 && mouseY < 325){
    cr3 = 169;
    if (mousePressed){
      r = 0;
      g = 0;
      b = 250;
    }
  }
  else{
    cr1 = 255;
    cr2 = 255;
    cr3 = 255;
  }
}
```
***
### 3.6 b
<div style="width: 100px;">

![overlap.gif](../../_resources/d3e873ddc83947edaa45387ec315c26b.gif)
</div>

```JAVA
void setup(){
  size(500, 500);
  strokeWeight(2);
}

void draw() {
  background(69);
  noFill();
  rect(x1, y1, 250, 250);
  rect(x2, y2, 250, 250);
  
  fill(r, g, b);
  ellipse(mouseX, mouseY, 70, 70);
  
  if(x2<mouseX&&mouseX <x2+250 && y2<mouseY&&mouseY< y2+250 && x1<mouseX&&mouseX <x1+250 && y1<mouseY&&mouseY< y1+250){
    r = 0;
    g = 0;
    b = 250;
  }
  else if (x1<mouseX&&mouseX <x1+250 && y1<mouseY&&mouseY< y1+250){
    r = 250;
    g = 0;
    b = 0;
  }
  else if (x2<mouseX&&mouseX <x2+250 && y2<mouseY&&mouseY< y2+250){
    r = 0;
    g = 250;
    b = 0;
  }
  else {
    r = 69;
    g = 69;
    b = 69;
  }
}
```
***
### 3.6 c
<div style="width: 100px;">

![raincatcher.gif](../../_resources/015bf28cb8f54b268240922c0b936cb3.gif)
</div>

```JAVA
int x = 250;
int score = 0;
int life = 0;

float q = 0;
float p = random(500);
float c = 255;

float q2 = 0;
float p2 = random(500);
float c2 = 255;

float q3 = 0;
float p3 = random(500);
float c3 = 255;
void setup(){
  size(500, 500);
  rectMode(CENTER);
  textSize(17);
}
void draw(){
  background(69);
  fill(255);
  text("score: " + score, 100, 30);
  text("life: " + life, 400, 30);
  //the 'bucket'
  fill(255);
  rect(x, 400, 150, 30);
  if (keyPressed){
    if (keyCode == RIGHT && x < 425){
    x+=2;
    }
    else if (keyCode == LEFT && x > 75){
      x-=2;
    }
  }
  // 1st ellipse
  fill(c);
  ellipse(p, q, 50, 50);
  q+=3;
  // if the ellipse reaches the bottom
  if (q > 500){
    p = random(25, 475);
    q = random(-200, 0);
    c = random(255);
    life--;
  } 
  // 2nd ellipse
  fill(c2);
  ellipse(p2, q2, 50, 50);
  q2+=3;
  if (q2 > 500){
    p2 = random(25, 475);
    q2 = random(-200, 0);
    c2 = random(255);
    life--;
  } 
  // 3rd ellipse
  fill(c3);
  ellipse(p3, q3, 50, 50);
  q3+=3;
  if (q3 > 500){
    p3 = random(25, 475);
    q3 = random(-200, 0);
    c3 = random(255);
    life--;
  }
  if (q+40 > 400 && p > x-150 && p < x+150){
    q = 0;
    p = random(25, 475);
    score++;
  }
  else if (q2+40 > 400 && p2 > x-150 && p2 < x+150){
    q2 = 0;
    p2 = random(25, 475);
    score++;
  }
  else if (q3+40 > 400 && p3 > x-150 && p3 < x+150){
    q3 = 0;
    p3 = random(25, 475);
    score++;
  }
  //Das ist ein unstylisher weg das zu lösen, aber es funktioniert
}
```
***
### 3.6 d
```JAVA
float ax = 250; // x-Position von Punkt a
int c = 255; //color of line
float bx = 25; // x-Position des Startpunkts der Linie b
float bwidth = 150; // Breite der Linie b
void setup(){
  size(500, 500);
}
void draw() {
  background(69);
  strokeWeight(25);

  stroke(0,255,0);
  point(ax, 250);
  
  stroke(255); 
  if (bx < ax && bx+bwidth > ax){
    c = 0;
  }
  else{
    c = 250;
  }
  stroke(255, c, c);
  line(bx, 300, bx+bwidth, 300);

  if (keyPressed) {
    if (keyCode == LEFT) {
      bx -= 2;
    } else if (keyCode == RIGHT) {
      bx += 2;
    }
  } 
}
```
***
### 3.6 e
<div style="width: 100px;">

![kollision.gif](../../_resources/73c556c560e14100a560dc54aa876ff2.gif)
</div>

```JAVA
float ax = 200;// x-Position von Punkt a
int awidth = 100;
int c = 255; //color of line
float bx = 25; // x-Position des Startpunkts der Linie b
float bwidth = 150;
// Breite der Linie b
void setup(){
  size(500, 500);
}
void draw() {
  background(69);
  strokeWeight(25);

  stroke(0,255,0);
  line(ax, 250, ax+awidth, 250);
  
  stroke(255); 
  if (bx < ax+awidth && bx+bwidth > ax){
    c = 0;
  }
  else{
    c = 250;
  }
  stroke(255, c, c);
  line(bx, 300, bx+bwidth, 300);

  if (keyPressed) {
    if (keyCode == LEFT) {
      bx -= 2;
    } else if (keyCode == RIGHT) {
      bx += 2;
    }
  } 
}
```
***
### 3.6 f
<div style="width: 100px;">

![pong.gif](../../_resources/1eef3d9524de43a589826e919e85226a.gif)
</div>

```JAVA
int x = 250;
int speedX = 4;
int speedY = 2;

int rectX = 250;
int rectY = 150;
boolean gameOver = false;
boolean spacePressed = false;
void setup(){
  size(500, 500);
  rectMode(CENTER);
}
void draw(){
  background(69);
  if (rectY == 370 && rectX > x-150 && rectX < x+150){
    speedY = -speedY;
  }
  // der Schläger
  fill(255);
  rect(x, 400, 150, 30);
  if (keyPressed){
    if (keyCode == RIGHT && x < 425){
    x+=3;
    }
    else if (keyCode == LEFT && x > 75){
      x-=3;
    }
  }
  //der Ball
  rect(rectX, rectY, 30, 30);
  if (keyPressed && key == 32){
    rectX = 250;
    rectY = 150;
    spacePressed = true;
    gameOver = false;
  }
  
  //start button
  if (spacePressed){
    rectX+=speedX;
    rectY+=speedY;
  }
  if (rectX >= width|| rectX <= 0){
    speedX = -speedX;
  }
  if (rectY <= 0){
    speedY = -speedY;
  }
  //game over
  else if (rectY >= height-30){
    spacePressed = false;
    rectX = 530;
    rectY = 530;
    gameOver = true;
  }
  if (gameOver == true){
    textSize(69);
    text("GAME OVER", 50, 150);
  }
}
```
***
### 3.6 g
<div style="width: 100px;">

![gateGame.gif](../../_resources/54b42479bc3f467b8f45358aec6f50f5.gif)
</div>
(Man sieht das Rot nicht, weil die Framerate vom gif nicht hochgenug ist)

```JAVA
int lineY = 250;
int rectX;
float rectY = random(10, 490);
int c = 0;
int score = 0;
void setup(){
  size(500, 500);
  strokeWeight(15);
}
void draw(){
  background(69);
  //Das Tor
  stroke(c,0,0);
  line(400, 0, 400, lineY);
   line(400, 500, 400, lineY+100);
  if (keyPressed && keyCode == DOWN){
    lineY+=5;
  }
  if (keyPressed && keyCode == UP){
    lineY-=5;
  }
  //Der Ball
  fill(0);
  rect(rectX, rectY, 10, 10);
  rectX+=6;
  if (rectX>500){
    rectX = 0;
    rectY = random(10, 490);
  }
  //Kollision
  if (rectX == 390 && rectY < lineY || rectX == 390 && rectY > lineY+100){
    c = 255;
    score--;
  }
  else if (rectX == 390 && rectY > lineY || rectX == 390 && rectY < lineY+100){
    score++;
  } 
  else{
    c = 0;
  }
  textSize(20);
  text(score, 30, 30);
  //Reset score
  if (keyPressed && key == 32){
    score = 0;
  }
}
```
***