Java Processing 1.1 - 1.2

# Java Processing
### 23.08.21
### 1.1 a

Ein Haus aus Dreieck und Quadrat

```j
void setup()
{
  size(500, 500);
  background(0);
}
void draw()
{
  //rectMode(CENTER);
  triangle(250, 250, 200, 300, 300, 300);
  rect(200, 300, 100, 100);
}
```
* * *
### 1.1 b

Halbkreis

```j
void setup()
{
  size(500, 500);
  background(0);
}

void draw()
{
  arc(250, 250 , 250 ,250, PI, 2*PI);
}
```
* * *
### 1.1c

Haus mit vertex

```j
void setup()
{
  size(500, 500);
  background(0);
}

void draw()
{
  beginShape();
  //vertex(250, 250);
  vertex(300, 300);
  vertex(300, 400);
  vertex(200, 400);
  vertex(200, 300);
 
  vertex(300, 300);
  vertex(250, 250);
  vertex(200, 300);
  endShape();
}
```
* * *
### 1.1 d

Mehr oder weniger Drudenfuß

```j
void setup()
{
  size(500, 500);
  background(0);
}


void draw()
{
  beginShape();
  
  vertex(200, 230);
  vertex(130, 400);
  vertex(300, 300);
  vertex(100, 300);
  vertex(270, 400);
  vertex(200, 230);
  
  endShape();
}
```
* * *
### 1.1 d

Smugface :)

```j
void setup()
{
  size(500, 500);
  background(0);
}


void draw()
{
  ellipseMode(CENTER);
  //Kopf
  ellipse(250, 250, 200, 200);
  //Augen
  ellipse(200, 230, 30, 30);
  ellipse(300, 230, 30, 30);
  //Nase
  triangle(250, 230, 230, 250, 270, 250);
  //Mund
  arc(250, 270, 150, 100, radians(0), radians(180));
}
```
* * *
### 1.1 f

Pyramide
50x50 Quadrate in 50er Schritten verschoben. Pro Reihe um halbe Breite des Quadrats (0.25) verschoben

```j
void setup()
{
  size(500, 500);
  background(0);
}


void draw()
{
  //50er SChritte in x und 
  rect(100,400, 50, 50);
  rect(150,400, 50, 50);
  rect(200,400, 50, 50);
  rect(250,400, 50, 50);
  
  //Um halbe Breite verschoben
  rect(125, 350, 50, 50);
  rect(175, 350, 50, 50);
  rect(225, 350, 50, 50);
  
  rect(150, 300, 50, 50);
  rect(200, 300, 50, 50);
  
  rect(175, 250, 50, 50);
  
  
}
```
* * *
* * *
### 1.2 a

0 ist Schwarz (ellipse)
255 ist Weiß (rect, triangle)

Ellipse und Rect sind schwarz
Triangle
* * *
### 1.2 b

Viereck. Weiß links Schwarz rechts.

```
void setup()
{
  size(500, 500);
  background(69);
}


void draw()
{
  fill(255);
  rect(50, 50, 70, 150);
  fill(0);
  rect(120, 50, 70, 150);
  
  
}
```
* * *
### 1.2 d

Gescicht mit schlechten Zähnen

```
void setup()
{
  size(500, 500);
  background(69);
}


void draw()
{
  ellipseMode(CENTER);
  //Kopf
  fill(0);
  ellipse(250, 250, 200, 200);
  //Augen
  fill(255);
  ellipse(230, 230, 40, 40);
  ellipse(270, 230, 40, 40);
  //Pupillen
  fill(0);
  ellipse(230, 230, 10, 10);
  ellipse(270, 230, 10, 10);
  
  fill(255);
  ellipse(210, 300, 30, 30);
  ellipse(290, 300, 30, 30);
  rect(210, 285, 80, 30);
  
  line(190, 300, 310 , 300);
  
  line(240, 285, 240, 320);
  line(270, 285, 270, 320);
  
}
```
* * *
### 1.2 e

Regenbogen

```
void setup()
{
  size(500, 500);
  background(0, 0, 255);
}


void draw()
{
  ellipseMode(CENTER);
  
  fill(200, 0 ,0);
  ellipse(250, 500, 500, 500);
  
  fill(250, 158 ,43);
  ellipse(250, 500, 400, 400);
  
  fill(250, 200 ,43);
  ellipse(250, 500, 300, 300);
  
  fill(0, 0 ,255);
  ellipse(250, 500, 200, 200);
}
```

* * *
